import os
import numpy as np
import tensorflow as ts
keras= ts.keras
models= keras.models
Sequential= models.Sequential
layers= keras.layers
Conv2D= layers.Conv2D
MaxPooling2D = layers.MaxPooling2D
Flatten = layers.Flatten
Dense = layers.Dense
Dropout = layers.Dropout

def getAsSoftmax(pathology):
    if (pathology == 'BENIGN'):
        return 0
    elif (pathology == 'MALIGNANT'):
        return 1
    elif (pathology == 'BENIGN_WITHOUT_CALLBACK'):
        return 0

def build_cnn(input_shape, num_classes):
    model = models.Sequential()
    model.add(layers.Conv2D(32, (3, 3), activation='relu', input_shape=input_shape))
    model.add(layers.MaxPooling2D((2, 2)))
    model.add(layers.Conv2D(64, (3, 3), activation='relu'))
    model.add(layers.MaxPooling2D((2, 2)))
    model.add(layers.Conv2D(128, (3, 3), activation='relu'))
    model.add(layers.MaxPooling2D((2, 2)))
    model.add(layers.Flatten())
    model.add(layers.Dense(512, activation='relu'))
    model.add(layers.Dense(num_classes, activation='softmax'))
    return model




