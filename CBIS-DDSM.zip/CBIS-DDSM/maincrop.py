import cv2
import os
import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
from sklearn.model_selection import train_test_split
import tensorflow as ts
import pydicom
from PIL import Image
keras= ts.keras
callbacks= keras.callbacks
EarlyStopping = callbacks.EarlyStopping
preprocessing=keras.preprocessing
image=preprocessing.image
ImageDataGenerator=image.ImageDataGenerator
metrics=keras.metrics
Precision=metrics.Precision
Recall=metrics.Recall
from scipy.ndimage import median_filter


from no_text import notext
from right_orientation import orientation
from crop import croops_roi3


dataset= pd.read_csv('C:/Users/fra-m/PycharmProjects/pythonProject/alldata.csv')
dest_dir = 'C:/Users/fra-m/PycharmProjects/pythonProject/vecchiodata_resize'



"""
for _, row in dataset.iterrows():
    image_id = row['image_id']
    # Ciclo attraverso le sottocartelle
    for subdir, _, files in os.walk(path):
        for file in files:
            # Confronta l'id dell'immagine con il nome del file senza l'estensione .dcm
            if file == f"{image_id}.dcm":
                dicom_paths.append(os.path.join(subdir, file))


"""

images = []

image_dir = "C:/Users/fra-m/PycharmProjects/pythonProject/full_images_vecchie"
files = os.listdir(image_dir)
immagini = [f for f in files if f.endswith(('.jpg', '.jpeg', '.png'))]

for nome_immagine in immagini:
    name_im= image_dir +'/'+ nome_immagine
    image = cv2.imread(name_im, cv2.IMREAD_GRAYSCALE)
    image=orientation(image)
    image=notext(image)
    [start_y, end_y, start_x, end_x] = croops_roi3(image)
    image = image[int(start_y):int(end_y), int(start_x):int(end_x)]
    image = cv2.resize(image, (512, 512), interpolation=cv2.INTER_NEAREST)
    name=os.path.basename(nome_immagine)
    output = os.path.join(dest_dir, name)
    cv2.imwrite(output, image)


