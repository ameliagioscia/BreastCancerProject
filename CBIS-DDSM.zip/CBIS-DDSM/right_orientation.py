import cv2
import os

def orientation(image):

    if image is not None:
        left_nonzero = cv2.countNonZero(image[:, 0:int(image.shape[1]/2)])
        right_nonzero = cv2.countNonZero(image[:, int(image.shape[1]/2):])

        if left_nonzero < right_nonzero:
            image = cv2.flip(image, 1)

        return image



