import pydicom
from PIL import Image
import numpy as np
import os

def windowing(image_data, window_center, window_width):

        # Calcola i limiti inferiore e superiore del range di finestra
        window_min = window_center - (window_width / 2)
        window_max = window_center + (window_width / 2)

        # Applica il windowing all'immagine DICOM
        image_data = np.clip(image_data, window_min, window_max)

        # Mappa il range al raggio dinamico di 8 bit (0-255)
        image_data = ((image_data - window_min) / (window_max - window_min) * 255).astype(np.uint8)

        return image_data


