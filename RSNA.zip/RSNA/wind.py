from pydicom.pixel_data_handlers import apply_windowing
import numpy as np
import pydicom
import matplotlib.pyplot as plt
import cv2


def apply_window(im,data):


    data = apply_windowing(data, im)


    if im.PhotometricInterpretation == "MONOCHROME1":
      data = np.amax(data) - data

    else:
      data = data - np.min(data)

    if np.max(data) != 0:
      data = data / np.max(data)


    data = (data * 255).astype(np.uint8)

    return data

