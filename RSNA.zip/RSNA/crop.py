import cv2
import pydicom
import numpy as np


def croops_roi3(img):

    blur = cv2.GaussianBlur(img, (5, 5), 0)
    _, breast_mask = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

    cnts, _ = cv2.findContours(breast_mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    cnt = max(cnts, key=cv2.contourArea)
    x, y, w, h = cv2.boundingRect(cnt)
    y_center= y + h/2
    g=min(h,w)
    start_x = x + 120
    end_x = x + g + 100
    start_y = y_center - (g // 2) - 250
    end_y = y_center + (g // 2) + 450


    return start_y, end_y, start_x, end_x
