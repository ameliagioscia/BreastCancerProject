import cv2
import os
import pandas as pd
import numpy as np
from PIL import Image
from matplotlib import pyplot as plt
from sklearn.model_selection import train_test_split
import tensorflow as ts
keras= ts.keras
callbacks= keras.callbacks
EarlyStopping = callbacks.EarlyStopping
ReduceLROnPlateau = callbacks.ReduceLROnPlateau
preprocessing=keras.preprocessing
image=preprocessing.image
ImageDataGenerator=image.ImageDataGenerator
metrics=keras.metrics
Precision=metrics.Precision
Recall=metrics.Recall
applications=keras.applications
ResNet50=applications.ResNet50
preprocess_input=applications.regnet.preprocess_input
KerasClassifier= keras.wrappers.scikit_learn.KerasClassifier
import shutil
from CNNvgg import build_cnn, F1Score

dataset = pd.read_csv('C:/Users/fra-m/PycharmProjects/pythonProject/bio.csv')

img=[]
label=[]


# Percorso alla cartella che contiene le immagini
image_dir = "C:/Users/fra-m/PycharmProjects/pythonProject/crop_bio"


files = os.listdir(image_dir)
immagini= [f for f in files if f.endswith(('.jpg', '.jpeg', '.png'))]

for nome_immagine in immagini:
    img_path = image_dir + '/' + nome_immagine

    im = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
    #im = cv2.resize(im, (224, 224))
    im = np.repeat(im[..., np.newaxis], 3, axis=2)
    img_id = int(nome_immagine.replace('.png',''))
    for index, riga in dataset.iterrows():
        if riga['image_id'] == img_id:
            pathology = riga['cancer']
            img.append(np.divide(np.asarray(im, np.float16), 255.))
            label.append(pathology)



# Prima suddivisione: 60% train, 40% temp
X_train, X_temp, y_train, y_temp = train_test_split(img, label, test_size=0.4, random_state=2018, stratify=label)

# Suddivisione di X_temp e y_temp: 50% val (20% dei dati originali) e 50% test (20% dei dati originali)
X_val, X_test, y_val, y_test = train_test_split(X_temp, y_temp, test_size=0.5, random_state=2018, stratify=y_temp)


cnn_model = build_cnn((512, 512, 3), 1)
cnn_model.compile(optimizer='adam',loss='binary_crossentropy',metrics=['accuracy', Precision(name='precision'), Recall(name='recall'), F1Score(name='f1_score')])
cnn_model.summary()

# Parametri di addestramento
EPOCHS = 50
BATCH_SIZE = 32

early_stop = EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=True)
reduce_lr= ReduceLROnPlateau(monitor='val_loss', factor=0.1, patience=5, min_lr=0.0001, verbose=1)



# 1. Creo un ImageDataGenerator con le trasformazioni desiderate
datagen = ImageDataGenerator(
    rotation_range=20,  # Rotazione casuale dell'immagine (0-40 gradi) 40
    width_shift_range=0.2,  # Traslazione orizzontale casuale 0.2
    height_shift_range=0.2,  # Traslazione verticale casuale 0.2
    shear_range=0.2,  # Applica una distorsione di taglio 0.2
    zoom_range=0.2,  # Zoom casuale 0.2
    horizontal_flip=True,  # Capovolge casualmente le immagini in orizzontale True
    fill_mode='nearest'  # Modo di riempimento dei pixel mancanti dopo la trasformazione
)
datagenval = ImageDataGenerator()
train_generator = datagen.flow(np.array(X_train), np.array(y_train), batch_size=BATCH_SIZE)

validation_data = datagenval.flow(np.array(X_val), np.array(y_val), batch_size=16)


history = cnn_model.fit(
    train_generator,
    epochs=EPOCHS,
    steps_per_epoch=20, #len(X_train) // BATCH_SIZE,  # Numero di step per epoca
    validation_data=validation_data,
    callbacks=[early_stop,reduce_lr]
)



"""

# Addestramento del modello senza Augmentation
history = cnn_model.fit(
    np.array(X_train), np.array(y_train),
    epochs=EPOCHS,
    batch_size=BATCH_SIZE,
    steps_per_epoch= 20,
    validation_data=(np.array(X_val), np.array(y_val)),
    callbacks=[early_stop,reduce_lr]
)

"""
#cnn_model.save('C:/Users/fra-m/PycharmProjects/pythonProject/CNNmodel3.h5')
plt.figure(figsize=(18, 4))

# Plot per Accuracy
plt.subplot(1, 5, 1)
plt.plot(history.history['accuracy'], label='Training Accuracy')
plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
plt.legend()
plt.title('Accuracy over epochs')

# Plot per Loss
plt.subplot(1, 5, 2)
plt.plot(history.history['loss'], label='Training Loss')
plt.plot(history.history['val_loss'], label='Validation Loss')
plt.legend()
plt.title('Loss over epochs')

# Plot per Precision
plt.subplot(1, 5, 3)
plt.plot(history.history['precision'], label='Training Precision')
plt.plot(history.history['val_precision'], label='Validation Precision')
plt.legend()
plt.title('Precision over epochs')

# Plot per Recall
plt.subplot(1, 5, 4)
plt.plot(history.history['recall'], label='Training Recall')
plt.plot(history.history['val_recall'], label='Validation Recall')
plt.legend()
plt.title('Recall over epochs')

# Plot per F1-score
plt.subplot(1, 5, 5)
plt.plot(history.history['f1_score'], label='Training F1 Score')
plt.plot(history.history['val_f1_score'], label='Validation F1 Score')
plt.legend()
plt.title('F1 Score over epochs')

plt.tight_layout()
plt.show()

#Valuta il modello sul set di test
test_loss, test_accuracy, test_precision, test_recall, test_f1score = cnn_model.evaluate(np.array(X_test), np.array(y_test), verbose=1)
print(f"Test Accuracy: {test_accuracy * 100:.2f}%")
print(f"Test Precision: {test_precision * 100:.2f}%")
print(f"Test Recall: {test_recall * 100:.2f}%")
print(f"Test F1 Score: {test_f1score:.2f}")
print(f"Test Loss: {test_loss:.4f}")



