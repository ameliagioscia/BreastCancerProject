import cv2
import os
import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
from sklearn.model_selection import train_test_split
import tensorflow as ts
import pydicom
from PIL import Image
keras= ts.keras
callbacks= keras.callbacks
EarlyStopping = callbacks.EarlyStopping
preprocessing=keras.preprocessing
image=preprocessing.image
ImageDataGenerator=image.ImageDataGenerator
metrics=keras.metrics
Precision=metrics.Precision
Recall=metrics.Recall
from scipy.ndimage import median_filter

from wind import apply_window
from no_text import notext
from right_orientation import orientation
from crop import croops_roi3
from windowing import windowing

path = 'D:/train_images'
dataset= pd.read_csv('C:/Users/fra-m/PycharmProjects/pythonProject/bio.csv')
dest_dir = 'C:/Users/fra-m/PycharmProjects/pythonProject/crop_bio'
dicom_paths = 'C:/Users/fra-m/PycharmProjects/pythonProject/immagini_bio_or'
files = os.listdir(dicom_paths)
immagini_dcm = [f for f in files if f.endswith('.dcm')]

"""
for _, row in dataset.iterrows():
    image_id = row['image_id']
    # Ciclo attraverso le sottocartelle
    for subdir, _, files in os.walk(path):
        for file in files:
            # Confronta l'id dell'immagine con il nome del file senza l'estensione .dcm
            if file == f"{image_id}.dcm":
                dicom_paths.append(os.path.join(subdir, file))

"""

images = []

for image_id in immagini_dcm:
    imagepath = dicom_paths + '/' + image_id
    ds = pydicom.dcmread(imagepath)

    if 'RescaleIntercept' in ds and 'RescaleSlope' in ds:
        slope = float(ds.RescaleSlope)
        intercept = float(ds.RescaleIntercept)
        img = slope * ds.pixel_array + intercept
    else:
        img = ds.pixel_array


    img_fi=apply_window(ds,img)

    nameim = os.path.splitext(os.path.basename(image_id))[0] + ".png"
    output = os.path.join(dest_dir, nameim)

    if np.all(img_fi == 0):
        im1 = windowing(img, 115, 200)
        clahe1 = cv2.createCLAHE(clipLimit=2, tileGridSize=(8, 8))
        im1= clahe1.apply(im1)
        im1 = orientation(im1)
        im1 = notext(im1)
        [start_y, end_y, start_x, end_x] = croops_roi3(im1)
        im1 = im1[int(start_y):int(end_y), int(start_x):int(end_x)]
        im1 = cv2.resize(im1, (512, 512), interpolation=cv2.INTER_NEAREST)
        Image.fromarray(im1).save(output)
    else:
        im = orientation(img_fi)
        im = notext(im)
        [start_y, end_y, start_x, end_x] = croops_roi3(im)
        im = im[int(start_y):int(end_y), int(start_x):int(end_x)]
        im = cv2.resize(im, (512, 512), interpolation=cv2.INTER_NEAREST)
        Image.fromarray(im).save(output)


