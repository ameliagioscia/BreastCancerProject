import os
import cv2
import numpy as np
import tensorflow as tf
keras= tf.keras
models= keras.models
Sequential= models.Sequential
layers= keras.layers
Conv2D= layers.Conv2D
MaxPooling2D = layers.MaxPooling2D
Flatten = layers.Flatten
GlobalAveragePooling2D = layers.GlobalAveragePooling2D
Dense = layers.Dense
Dropout = layers.Dropout
metrics=keras.metrics
Precision=metrics.Precision
Recall=metrics.Recall
applications=keras.applications
BatchNormalization=layers.BatchNormalization
regularizers=keras.regularizers


def build_cnn(input_shape, num_classes):
 base_model = applications.ResNet50V2(weights='imagenet', input_shape=input_shape, include_top=False)

 for layer in base_model.layers:
#for layer in base_model.layers[:-3]: Fine tuning
    layer.trainable = False

 model = Sequential()
 model.add(base_model)
 model.add(GlobalAveragePooling2D())
 model.add(Dense(128, activation='relu')) #, kernel_regularizer=regularizers.l1(0.01)))
 model.add(Dropout(0.5))
 model.add(Dense(num_classes, activation='sigmoid'))
 return model

class F1Score(tf.keras.metrics.Metric):
        def __init__(self, name='f1_score', **kwargs):
            super(F1Score, self).__init__(name=name, **kwargs)
            self.precision = Precision()
            self.recall = Recall()

        def update_state(self, y_true, y_pred, sample_weight=None):
            self.precision.update_state(y_true, y_pred, sample_weight)
            self.recall.update_state(y_true, y_pred, sample_weight)

        def result(self):
            precision = self.precision.result()
            recall = self.recall.result()
            return 2 * ((precision * recall) / (precision + recall + tf.keras.backend.epsilon()))

        def reset_state(self):
            self.precision.reset_state()
            self.recall.reset_state()


