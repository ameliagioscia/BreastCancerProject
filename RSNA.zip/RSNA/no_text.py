import cv2
import os
import pandas as pd
import numpy as np

def notext(pixel_data):

  bin_pixels = cv2.threshold(pixel_data, 20, 255, cv2.THRESH_BINARY)[1]


  contours, _ = cv2.findContours(bin_pixels, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
  contour = max(contours, key=cv2.contourArea)


  mask = np.zeros(pixel_data.shape, np.uint8)
  cv2.drawContours(mask, [contour], -1, 255, cv2.FILLED)


  out = cv2.bitwise_and(pixel_data, mask)
  return out